# Ansible Collection - common.roles

Documentation for the collection.